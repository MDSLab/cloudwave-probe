CloudWave Python Config Parser
-------------------------------------
This version requires Python 2.6 or later.
