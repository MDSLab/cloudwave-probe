import os
from setuptools import setup, find_packages

def read(fname):
	return open(os.path.join(os.path.dirname(__file__), fname)).read()

setup(
      	name = "cwConfParser",
        #packages = ["cwconfparser",],
	packages = find_packages(),
        version = "1.0",
        description = "CloudWave Python Config Parser.",
        author = "UniMe Team - Nicola Peditto, Fabio Verboso",
        author_email = "npeditto@unime.it, fverboso@unime.it",
        url = "http://www.cloudwave-fp7.eu/",
        download_url = "",
        keywords = ["parser", "lib", "configuration", "cloudwave"],
        classifiers = [
                "Programming Language :: Python",
                "Programming Language :: Python :: 2.7",
                "Development Status :: 4 - Beta",
                "Environment :: Other Environment",
                "Intended Audience :: Developers",
                "License :: OSI Approved :: GNU General Public License (GPL)",
                "Operating System :: OS Independent",
                "Topic :: Software Development :: Libraries :: Python Modules",
        ],
	license='GPL',

        install_requires=[
                'setuptools',
		'greenlet',
		'ConfigParser',
        ],
	zip_safe=False,
	long_description=read('README.txt')


)

