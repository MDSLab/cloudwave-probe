import ConfigParser
import os.path
import sys

def getOptions(path,section):
	conf=ConfigParser.ConfigParser()
	"""
	if os.path.isfile(path) is False: 
		print "ERROR cannot find configuration file! Exit..." 
		sys.exit()
	"""
	conf.read(path)
	dict = {}
	options = conf.options(section)
	for option in options:
		try:
		    dict[option] = conf.get(section, option)
		    if dict[option] == -1:
			print("skip: %s" % option)
		except:
		    print("exception on %s!" % option)
		    dict[option] = None
    	return dict


#print getOptions("/home/fabio/cw.conf","sezione") 
