import os
from setuptools import setup, find_packages

def read(fname):
	return open(os.path.join(os.path.dirname(__file__), fname)).read()

setup(
      	name = "PyLogLib",
        packages = ["pyloglib",],
        version = "1.0",
        description = "CloudWave Python log library.",
        author = "UniMe Team - Nicola Peditto",
        author_email = "npeditto@unime.it",
        url = "http://www.cloudwave-fp7.eu/",
        download_url = "",
        keywords = ["log", "lib", "logging", "rsyslog"],
        classifiers = [
                "Programming Language :: Python",
                "Programming Language :: Python :: 2.6",
                "Development Status :: 4 - Beta",
                "Environment :: Other Environment",
                "Intended Audience :: Developers",
                "License :: OSI Approved :: GNU General Public License (GPL)",
                "Operating System :: OS Independent",
                "Topic :: Software Development :: Libraries :: Python Modules",
                "Topic :: Text Processing :: Linguistic",
        ],
	license='GPL',
        install_requires=[
                'setuptools',
		'greenlet',
		'logging',
		'datetime',
        ],
	zip_safe=False,
	long_description = read('README.txt')

)

