from pyloglib import PyLogLib

tag='COMPONENT-X'


##Only remote logging
#logger=PyLogLib(tag)

#Remote + Local logging
logger=PyLogLib(tag, filename="cloudwave.log")

#All supported log levels
logger.debug("Here is some DEBUG") 
logger.info("Here is some INFO")
logger.warn("Here is some WARN")
logger.error("Here is some ERROR")
logger.fatal("Here is some FATAL")
