import logging,socket,datetime
from logging.handlers import SysLogHandler

class PyLogLib():
    
    def __init__(self, tag, filename=""):
        
        #Parameters
        self.logfile=filename
        self.ipserver="ing-wn-21.me.trigrid.it"	#Rsyslog server IP address
        self.port=514	#UDP port of the service
        self.tag=tag
        
        #Logging configuration
        self.datatime=(datetime.datetime.today()).strftime("%b %d %Y %H:%M:%S")
        self.host=str(socket.gethostname())
        myformat=self.host+' ' + tag +'[%(process)d]: %(message)s'
        self.logger = logging.getLogger()
        self.logger.setLevel(logging.DEBUG)
        
        #Remote logging
        syslog = SysLogHandler(address=(self.ipserver, self.port))
        formatter = logging.Formatter(myformat)
        syslog.setFormatter(formatter)
        self.logger.addHandler(syslog)
        
        #Local logging
        if self.logfile != "":
            hdlr=logging.FileHandler(self.logfile)
            formatter2 = logging.Formatter(self.datatime+' '+myformat)
            hdlr.setFormatter(formatter2)
            self.logger.addHandler(hdlr)
            
            

    def debug(self,msg):
        self.logger.debug(msg) 
        
    def info(self,msg):
        self.logger.info(msg) 

    def warn(self,msg):
        self.logger.warn(msg) 

    def error(self,msg):
        self.logger.error(msg) 

    def fatal(self,msg):
        self.logger.fatal(msg) 
        
