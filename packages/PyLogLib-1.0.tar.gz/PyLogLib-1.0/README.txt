CloudWave Python Log library
-------------------------------------
This version requires Python 2.6 or later.
